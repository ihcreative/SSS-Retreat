import React from 'react';
import { Link } from 'react-router-dom';

const NavBar: React.FC = () => {
  // Smooth scroll handler for anchor links
  const handleScroll = (e: React.MouseEvent<HTMLAnchorElement, MouseEvent>, targetId: string) => {
    e.preventDefault();
    const element = document.getElementById(targetId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav className="fixed top-0 left-0 w-full bg-white border-b border-[#D7D2C8] z-50" style={{ height: '80px' }}>
      <div className="container mx-auto px-6 md:px-8 flex items-center justify-between h-full">
        
        {/* Logo */}
        <Link to="/" className="flex items-center">
          <img src="https://i.ibb.co/7jZ6T2K/sss-logo-final.png" alt="Second Spring Sisterhood Logo" className="h-[60px] w-auto" />
        </Link>

        <div className="hidden md:flex items-center space-x-6">
          <a 
            href="#welcome" 
            onClick={e => handleScroll(e, 'welcome')}
            className="text-sm font-medium text-[#5A514C] hover:underline transition"
          >
            About
          </a>
           <a 
            href="#flow" 
            onClick={e => handleScroll(e, 'flow')}
            className="text-sm font-medium text-[#5A514C] hover:underline transition"
          >
            The Vibe
          </a>
          <a 
            href="#included" 
            onClick={e => handleScroll(e, 'included')}
            className="text-sm font-medium text-[#5A514C] hover:underline transition"
          >
            What's Included
          </a>
          {/* Retreat Guide link */}
          <a 
            href="#retreat-guide" 
            onClick={e => handleScroll(e, 'retreat-guide')}
            className="text-sm font-medium text-[#5A514C] hover:underline transition"
          >
            Retreat Guide
          </a>

          {/* CTA Button */}
          <a 
            href="#register" 
            onClick={e => handleScroll(e, 'register')}
            className="bg-[#4A5A3A] text-white px-6 py-3 rounded-full font-bold text-sm hover:bg-[#3C4B2E] transition-all duration-300 transform hover:scale-105 hover:shadow-lg"
          >
            Save My Spot
          </a>
        </div>
      </div>
    </nav>
  );
};

export default NavBar;